#include <random>
int main()
{
  typedef std::uniform_int_distribution<std::size_t> Distribution;
}

